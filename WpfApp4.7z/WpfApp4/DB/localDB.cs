﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp4.Models;

namespace WpfApp4.DB
{
    public class localDB
    {
        public localDB()
        {
            Init();
        }
        private List<Student> Studentls;
        private void Init()
        {
            Studentls = new List<Student>();
            for(int i = 0; i < 30; i++)
            {
                Studentls.Add(new Student() { Id = i ,Name=$"Sample{i}"}) ;
            }
        }

        public List<Student> GetStudentls()
        {
            return Studentls;
        }
        public void AddStudent(Student stu)
        {
            Studentls.Add(stu);
        }
        public void DeleteStudent(int id)
        {
            var stu= Studentls.FirstOrDefault(t=>t.Id==id);
            if(stu != null)
                Studentls.Remove(stu);
        }
        public List<Student> GetStudentsByName(string name)
        {
            return Studentls.Where(q=>q.Name.Contains(name)).ToList();
        }
        public Student GetStudentById(int id)//防止引用传递
        {
            var model=Studentls.FirstOrDefault(t=>t.Id == id);
            if (model != null)
                return new Student{Id = model.Id,Name = model.Name};
            return null;
        }
    }
}
