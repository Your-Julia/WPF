using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using WpfApp4.DB;
using WpfApp4.Models;
using WpfApp4.Views;

namespace WpfApp4.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        localDB localDb;
        public MainViewModel()
        {
            localDb =new localDB();
            this.Query();
            QueryCommand = new RelayCommand(Query);
            ResetCommand = new RelayCommand(Reset);
            AddCommand = new RelayCommand(Add);
            EditCommand = new RelayCommand<int>(t=>Edit(t));
            DeleteCommand = new RelayCommand<int>(t=>Delete(t));
        }
        
        private ObservableCollection<Student> gridModelList;
        public ObservableCollection<Student> GridModelList
        {
            get { return gridModelList; }
            set { gridModelList = value; RaisePropertyChanged(); }
        }


        private string search=string.Empty;
        public string Search
        {
            get { return search; }
            set { search = value;RaisePropertyChanged();}
        }
        public RelayCommand QueryCommand { get; set; }
        public void Query()
        {
            var models = localDb.GetStudentsByName(Search);
            GridModelList = new ObservableCollection<Student>();
            if (models != null)
            {
                models.ForEach(arg =>
                {
                    GridModelList.Add(arg);
                });
            }
        }

        public RelayCommand ResetCommand { get; set; }
        public void Reset()
        {
            Search = string.Empty;
            this.Query();
        }

        public RelayCommand AddCommand { get; set; }
        public void Add()
        {
            Student stu=new Student();
            UserView uvm = new UserView(stu);
            var res = uvm.ShowDialog();
            if (res.Value)
            {
                stu.Id = GridModelList.Max(t => t.Id) + 1;
                localDb.AddStudent(stu);
                this.Query();
            }
        }

        public RelayCommand<int> EditCommand { get; set; }
        public void Edit(int id)
        {
            var model=localDb.GetStudentById(id);
            if (model != null)
            {
                UserView uvm = new UserView(model);//��ֹ���ô���
                var res=uvm.ShowDialog();
                if (res.Value)
                {
                    var stu= GridModelList.FirstOrDefault(t => t.Id == model.Id);
                    if(stu != null)
                    {
                        stu.Name=model.Name;
                    }
                }
            }
        }
        public RelayCommand<int> DeleteCommand { get; set; }
        public void Delete(int id)
        {
            var model = localDb.GetStudentById(id);
            if (model != null)
            {
                var res = MessageBox.Show($"ȷ��ɾ����ǰ�û�{model.Name}?", "������ʾ", MessageBoxButton.OK, MessageBoxImage.Question);
                if (res == MessageBoxResult.OK)
                    localDb.DeleteStudent(model.Id);
                this.Query();
            }
        }
    }
}